#ifndef _THERMOMETER_PAGE_H_
#define _THERMOMETER_PAGE_H_

#include "GlobalDefines.h"
#include "RenderTemperature.h"
#include "RenderPowerBar.h"
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

void ThermometerPage_Init(int16_t integerValue, int16_t tenthValue, uint8_t powerSetpoint);
void ThermometerPage_UpdateTemperature(int16_t newIntegerValue, uint8_t newTenthValue);
void ThermometerPage_UpdatePowerSetpoint(uint8_t newValue);

#endif // _THERMOMETER_PAGE_H_
