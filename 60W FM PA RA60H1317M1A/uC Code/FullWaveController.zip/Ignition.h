#ifndef _IGNITION_H_
#define _IGNITION_H_

#include "GlobalDefines.h"
#include "HardwareDefines.h"

void DoIgnition(uint8_t powerSetpoint);

#endif // _IGNITION_H_
