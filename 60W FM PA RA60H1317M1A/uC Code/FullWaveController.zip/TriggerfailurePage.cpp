#include "TriggerfailurePage.h"

void TriggerfailurePage_Init(void)
{
	display.clearDisplay();
	
	// Draw 1px border
	display.drawRect(0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT, WHITE);
	
	// Use default small font for message text
	display.setFont();
	
	// Character size: 8x5 + 1px space
	display.setCursor(47, 6);
	display.print("Fehler");
	display.setCursor(4, 17);
	display.print("Netzsynchronisierung");
	
	display.display();
}
