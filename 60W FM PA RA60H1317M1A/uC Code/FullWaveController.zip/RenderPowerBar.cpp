#include "RenderPowerBar.h"

static const uint8_t yPos = DISPLAY_HEIGHT - 1;
static const uint8_t xPos = DISPLAY_WIDTH - 2;
static const uint8_t barWidth = 2;


void RenderPowerBar(uint8_t value)
{
	uint8_t barLength = ((uint16_t)value * (uint16_t)DISPLAY_HEIGHT) / MAX_POWER_LEVEL;
	
	//fillRect(x0, y0, w, h, color);
	display.fillRect(xPos, 0, barWidth, DISPLAY_HEIGHT - barLength, BLACK);
	display.fillRect(xPos, DISPLAY_HEIGHT - barLength, barWidth, barLength, WHITE);
}