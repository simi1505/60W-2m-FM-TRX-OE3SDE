#ifndef _SPIMASTER_H_
#define _SPIMASTER_H_

void Max31855_ConfigureSpiMaster(void);
int8_t Max31855_ReadTemperature(int16_t *pTemperature, uint8_t *pTemperatureTenth);

#endif /* _SPIMASTER_H_ */
