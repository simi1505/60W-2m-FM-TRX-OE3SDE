#include "Ignition.h"


const uint8_t nvIgnitionPattern[] PROGMEM = {
	0x00, 0x00, 0x00,	/* 0 */
	0x80, 0x00, 0x00,	/* 1 */
	0x80, 0x08, 0x00,	/* 2 */
	0x80, 0x80, 0x80,	/* 3 */
	0x82, 0x08, 0x20,	/* 4 */
	0x84, 0x21, 0x08,	/* 5 */
	0x88, 0x88, 0x88,	/* 6 */
	0x91, 0x22, 0x44,	/* 7 */
	0x92, 0x49, 0x24,	/* 8 */
	0x92, 0x92, 0x52,	/* 9 */
	0x94, 0xA9, 0x4A,	/* 10 */
	0x95, 0x54, 0xAA,	/* 11 */
	0xAA, 0xAA, 0xAA,	/* 12 */
	0xD5, 0x5A, 0xAA,	/* 13 */
	0xD6, 0xAD, 0x6A,	/* 14 */
	0xDA, 0xDA, 0xDA,	/* 15 */
	0xDB, 0x6D, 0xB6,	/* 16 */
	0xED, 0xDB, 0xB6,	/* 17 */
	0xEE, 0xEE, 0xEE,	/* 18 */
	0xF7, 0xBD, 0xEE,	/* 19 */
	0xFB, 0xEF, 0xBE,	/* 20 */
	0xFE, 0xFE, 0xFE,	/* 21 */
	0xFF, 0xF7, 0xFE,	/* 22 */
	0xFF, 0xFF, 0xFE,	/* 23 */
	0xFF, 0xFF, 0xFF	/* 24 */
};


inline uint32_t ReadIgnitionPattern(uint8_t powerLevel)
{
	uint16_t memoryOffset = powerLevel * 3;
	
	if (powerLevel > MAX_POWER_LEVEL)
	{
		return 0;
	}
	
	/* Typecasts are necessary - otherwise we'll get odd results for numbers > 16 bit */
	uint32_t ignitionPattern =
		  (uint32_t)pgm_read_byte(nvIgnitionPattern + memoryOffset + 0) * 0x10000
		+ (uint16_t)pgm_read_byte(nvIgnitionPattern + memoryOffset + 1) * 0x100
		+ (uint8_t) pgm_read_byte(nvIgnitionPattern + memoryOffset + 2);
	
	return ignitionPattern;
}


void DoIgnition(uint8_t powerSetpoint)
{
	static uint8_t oldPowerSetpoint = 0;
	static uint8_t currentCycle = 0;
	static uint32_t ignitionPattern = 0;
	static uint32_t setIgnitionPattern = 0;
	
	/* Do the acual ignition */
	if (ignitionPattern & 0x1)
	{
		IGNITION_SET();
	}
	else
	{
		IGNITION_CLEAR();
	}
	
	/* Load next pattern bit */
	ignitionPattern >>= 1;
	
	/* Max. power level defines also the amount of cycles */
	if (++currentCycle >= MAX_POWER_LEVEL)
	{
		/* Power level changed - Load new value */
		if (oldPowerSetpoint != powerSetpoint)
		{
			setIgnitionPattern = ReadIgnitionPattern(powerSetpoint);
			ignitionPattern = setIgnitionPattern;
			oldPowerSetpoint = powerSetpoint;
		}
		
		ignitionPattern = setIgnitionPattern;
		currentCycle = 0;
	}
}
