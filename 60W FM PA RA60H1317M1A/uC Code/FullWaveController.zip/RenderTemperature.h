#ifndef _RENDER_TEMPERATURE_H_
#define _RENDER_TEMPERATURE_H_

#include "GlobalDefines.h"
#include "ReducedFreeSans.h"
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

typedef enum { NO_DECIMAL = 0, SHOW_DECIMAL = 1 } DecimalType;
typedef enum { SMALL_UNIT = 0, LARGE_UNIT = 1 } UnitType;

// x / y defines the lower right corner of the unit text
void RenderTemperature(uint8_t x, uint8_t y, int16_t integerValue, uint8_t tenthValue, DecimalType decimal, UnitType unit);

#endif // _RENDER_TEMPERATURE_H_
