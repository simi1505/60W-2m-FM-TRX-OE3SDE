#ifndef _HARDWARE_DEFINES_H_
#define _HARDWARE_DEFINES_H_

//#define F_CPU						8000000UL

#define ENCODER_A_BIT				(1 << PD3)
#define ENCODER_B_BIT				(1 << PB6)
#define ENCODER_S_BIT				(1 << PB7)

#define ENCODER_A					(!(PIND & ENCODER_A_BIT))
#define ENCODER_B					(!(PINB & ENCODER_B_BIT))
#define ENCODER_S_PRESSED			(!(PINB & ENCODER_S_BIT))

#define BUTTON_A_BIT				(1 << PB5)
#define BUTTON_B_BIT				(1 << PD7)
#define BUTTON_C_BIT				(1 << PC6)

#define BUTTON_A_PRESSED			(!(PINB & BUTTON_A_BIT))
#define BUTTON_B_PRESSED			(!(PIND & BUTTON_B_BIT))
#define BUTTON_C_PRESSED			(!(PINC & BUTTON_C_BIT))

#define IGNITION_BIT				(1 << PD6)
#define IGNITION_SET()				PORTD |= IGNITION_BIT
#define IGNITION_CLEAR()			PORTD &= ~IGNITION_BIT

#define LED_BIT						(1 << PC7)
#define LED_SET()					PORTC |= LED_BIT
#define LED_TOGGLE()				PORTC ^= LED_BIT
#define LED_CLEAR()					PORTC &= ~LED_BIT

#define TRIGGER_BIT					(1 << PD2)
#define SPI_SCK_BIT					(1 << PB1)
#define SPI_HW_NSS_BIT				(1 << PB0)

#define SPI_NSS_PORT				PORTF
#define SPI_NSS_BIT					(1 << PF0)

#define TIMER1_PRELOAD_10MS			0xD8F0
#define TIMER1_PRELOAD_25MS			0x9E58
#define TIMER3_PRELOAD_500MS		0xC2F7

#define STOP_TIMER3() 				{ TCCR3B = 0; }
#define START_TIMER3() 				{ TCNT3 = TIMER3_PRELOAD_500MS; TCCR3B = (4 << CS30); /* clk:256 */ }

#endif // _HARDWARE_DEFINES_H_