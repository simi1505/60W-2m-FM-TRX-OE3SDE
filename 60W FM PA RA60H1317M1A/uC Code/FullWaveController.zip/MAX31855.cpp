#include <avr/io.h>
#include "HardwareDefines.h"


//-------------------- TIMER --------------------//
#define TIMER_PRELOAD_1MS		0xFF83

#define TIMER4_IS_STOPPED		(TCCR4B == 0)
#define TIMER4_IS_ELAPSED		(TIFR4 & (1 << TOV4))

#define STOP_TIMER4() { TCCR4B = 0; }

#define START_TIMER4() { \
	TC4H = (uint8_t)(TIMER_PRELOAD_1MS >> 8); \
	TCNT4 = (uint8_t)TIMER_PRELOAD_1MS; \
	TIFR4 |= (1 << TOV4); \
	TCCR4B = (7 << CS40); /* fOsc:64 */ \
}

static inline void ConfigureTimer4(void)
{
	TCCR4B = 0;	// Don't start right now
	TIFR4 |= (1 << TOV4);
}

//-------------------- SPI --------------------//

#define SLAVE_SELECT()			SPI_NSS_PORT &= ~SPI_NSS_BIT;
#define SLAVE_UNSELECT()		SPI_NSS_PORT |= SPI_NSS_BIT;

void Max31855_ConfigureSpiMaster(void)
{
	DDRB |= SPI_HW_NSS_BIT;		/* Hardware /SS */
	PORTB &= ~SPI_HW_NSS_BIT;
	
	DDRB |= SPI_SCK_BIT;		/* SCK */
	PORTB &= ~SPI_SCK_BIT;
	
	DDRF |= SPI_NSS_BIT;		/* Real /SS */
	SLAVE_UNSELECT();
	
	SPCR = (1 << SPE) | (1 << MSTR) | (0 << CPOL) | (0 << CPHA) | (0 << SPR0);
	SPSR = (1 << SPI2X); /* max. SPI clock = fosc / 2 */ \
	ConfigureTimer4();
}

#define SPI_TRANSFER_COMPLETE	(SPSR & (1 << SPIF))

uint8_t Max31855_SpiMasterTransfer(uint8_t data)
{
	SPDR = data;
	
	START_TIMER4();
	{
		// Wait for SPI complete or timeout
		while (!SPI_TRANSFER_COMPLETE && !TIMER4_IS_ELAPSED);
	}
	STOP_TIMER4();
	
	// In case of timeout, return 0
	return (SPI_TRANSFER_COMPLETE) ? SPDR : 0;
}

#define SIGN_BIT			11
#define INTEGER_LSB			4
#define DECIMAL_LSB			3
#define FAULT_BIT 			0

#define INTEGER_MASK		0x7FF

#define SPI_READ_DUMMY		0xFF

int8_t Max31855_ReadTemperature(int16_t *pTemperature, uint8_t *pTemperatureTenth)
{
	uint16_t rawValue = 0;
	
	SLAVE_SELECT();
	{
		rawValue = Max31855_SpiMasterTransfer(SPI_READ_DUMMY) * 0x100
				 + Max31855_SpiMasterTransfer(SPI_READ_DUMMY);
		
		// We simply ignore the lower 16 bit - 32 bit values are a pain to work with on a 8 bit CPU
		Max31855_SpiMasterTransfer(SPI_READ_DUMMY);
		Max31855_SpiMasterTransfer(SPI_READ_DUMMY);
	}
	SLAVE_UNSELECT() 
	
	// Bits 19..18 hold the decimal precision in 1/4 K
	// We only use 1/2 K precision, 0.25 K steps are hard to read.
	uint8_t thermoTemperatureTenth = ((rawValue >> DECIMAL_LSB) & 0x1) * 5;
		
	// Bits 31..18 contain thermocouple temperature
	int16_t thermoTemperature = ((rawValue >> INTEGER_LSB) & INTEGER_MASK);
	
	uint8_t negative = ((rawValue >> SIGN_BIT) & 0x1);
	if (negative)
	{
		thermoTemperature |= ~INTEGER_MASK;
	}
	
	if (pTemperature)
	{
		*pTemperature = thermoTemperature;
	}
	
	if (pTemperatureTenth)
	{
		*pTemperatureTenth = thermoTemperatureTenth;
	}
	
	uint8_t fault = ((rawValue >> FAULT_BIT) & 0x1);
	return fault;
}
