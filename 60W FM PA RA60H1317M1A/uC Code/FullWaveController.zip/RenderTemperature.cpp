#include "RenderTemperature.h"

#define LARGE_UNIT_WIDTH	31
#define SMALL_UNIT_WIDTH	17
#define LARGE_TEXT_HEIGHT	16
#define SMALL_TEXT_HEIGHT	6
#define UNIT_SPACE			5
#define ERROR_TEXT_WIDTH	22

static const char _smallDegree = 247;		// 247 is the ° in the default (small) font

uint8_t GetValueWidth(int16_t value)
{
	// Values are determined empirically resp. from the font file
	// This static method makes appearance more stable compared to getTextBounds()
	uint8_t negativeSignWidth = 0;
	
	if (value < 0)
	{
		negativeSignWidth = 8;
		value *= -1;
	}
	
	if (value < 10)
	{
		return 11 + negativeSignWidth;
	}
	if (value < 100)
	{
		return 24 + negativeSignWidth;
	}
	return 37 + negativeSignWidth;
}

// x / y defines the lower right corner of the unit text
void RenderTemperature(uint8_t x, uint8_t y, int16_t integerValue, uint8_t tenthValue, DecimalType decimal, UnitType unit)
{
	uint8_t unitWidth = (unit == LARGE_UNIT) ? LARGE_UNIT_WIDTH : SMALL_UNIT_WIDTH;
		
	display.setFont(&ReducedFreeSans);
	
	if (integerValue == TEMPERATURE_ERROR)
	{
		display.setCursor(x - unitWidth - ERROR_TEXT_WIDTH, y);
		display.print("---");
		return;
	}

	display.setCursor(x - unitWidth - UNIT_SPACE - GetValueWidth(integerValue), y);
	display.print(integerValue);
	
	if (unit == LARGE_UNIT)
	{
		display.setCursor(x - unitWidth, y);
		display.print(" !C");	// ! is replaced by ° in the font file
		
		if (decimal == SHOW_DECIMAL)
		{
			display.setFont();
			display.setCursor(x - unitWidth, y - SMALL_TEXT_HEIGHT); // Just 1 pixel more space is perfect
			display.print(tenthValue);
		}
	}
	else
	{
		display.setFont();
		display.setCursor(x - unitWidth, y - LARGE_TEXT_HEIGHT);
		display.print(_smallDegree);
		display.print("C");
		
		if (decimal == SHOW_DECIMAL)
		{
			display.setCursor(x - unitWidth, y - SMALL_TEXT_HEIGHT);
			display.print(tenthValue);
		}
	}
}