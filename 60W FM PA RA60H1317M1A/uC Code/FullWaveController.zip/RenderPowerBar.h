#ifndef _RENDER_POWERBAR_H_
#define _RENDER_POWERBAR_H_

#include "GlobalDefines.h"
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

void RenderPowerBar(uint8_t value);

#endif // _RENDER_POWERBAR_H_
