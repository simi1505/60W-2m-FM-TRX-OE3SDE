#ifndef _GLOBAL_DEFINES_H
#define _GLOBAL_DEFINES_H

#include <Adafruit_SSD1306.h>

#define MIN_POWER_LEVEL				0
#define MAX_POWER_LEVEL				24
#define MIN_TEMPERATURE_SETPOINT	-50
#define MAX_TEMPERATURE_SETPOINT	500

#define TEMPERATURE_ERROR			-32768

#define DELTA_T						10
#define PRECISION_DELTA_T			1

#define BACKLIGHT_TIMEOUT			(10 * 10)
#define SCREENSAVER_TIMEOUT			(30 * 60 * 10)

#define DISPLAY_WIDTH				128
#define DISPLAY_HEIGHT				32

#define WHITE						SSD1306_WHITE
#define BLACK						SSD1306_BLACK

#define LIMIT(_X, _MIN, _MAX)		if (_X > _MAX) { _X = _MAX; } else if (_X < _MIN) { _X = _MIN; }

#endif // _GLOBAL_DEFINES_H