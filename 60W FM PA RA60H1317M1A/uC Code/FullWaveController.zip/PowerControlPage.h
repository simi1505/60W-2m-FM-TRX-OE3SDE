#ifndef _POWER_CONTROL_PAGE_H_
#define _POWER_CONTROL_PAGE_H_

#include "GlobalDefines.h"
#include "ReducedFreeSans.h"
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

void PowerControlPage_Init(void);
void PowerControlPage_UpdateSetpoint(uint8_t newValue);

#endif // _POWER_CONTROL_PAGE_H_
