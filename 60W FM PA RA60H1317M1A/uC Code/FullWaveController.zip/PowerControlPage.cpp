#include "PowerControlPage.h"

static const uint8_t _stepSizePixel = 4;	// Width of one value step
static const uint8_t _textOffsetX = 103;	// X offset of numeric value
static const uint8_t _textOffsetY = 28;		// Y offset of numeric value
static const uint8_t _maxTextWidth = 24;	// Largest width of font used (2 digits; determined empirically)
static const uint8_t _maxTextHeight = 17;	// Largest height of font used (determined empirically)

static uint8_t _oldValue = 0;

void PowerControlPage_DrawBargraph(uint8_t newValue)
{
	// Bargraph filling is 1px smaller than border - clear old value, then draw new value
	if (_oldValue > newValue)
	{
		display.fillRoundRect(1, 10, _oldValue * _stepSizePixel, 21, 2, BLACK);
	}
	display.fillRoundRect(1, 10, newValue * _stepSizePixel, 21, 2, WHITE);
}

void PowerControlPage_DrawNumericValue(uint8_t value)
{
	// Center text (0-9: max. width = 11 px, 10-24: max. width = 24 px)
	// Position is the LOWER left corner of the text (bug in custom font rendering?)
	display.setCursor((value < 10) ? _textOffsetX + 6 : _textOffsetX, _textOffsetY);
	// Clear old text
	display.fillRect(_textOffsetX + 1, _textOffsetY - _maxTextHeight + 1, _maxTextWidth, _maxTextHeight, BLACK);
	
	display.print(value);
}

void PowerControlPage_UpdateSetpoint(uint8_t newValue)
{
	// Nothing changed - nothing to draw
	if (newValue > MAX_POWER_LEVEL || newValue == _oldValue)
	{
		return;
	}
	
	PowerControlPage_DrawBargraph(newValue);
	PowerControlPage_DrawNumericValue(newValue);
	display.display();
	
	_oldValue = newValue;
}

void PowerControlPage_Init(void)
{
	display.clearDisplay();
	display.setFont(&ReducedFreeSans);
	
	// Draw border        x, y, w,  h,  r, color
	display.drawRoundRect(0, 9, 98, 23, 3, WHITE);
	
	PowerControlPage_DrawBargraph(_oldValue);
	PowerControlPage_DrawNumericValue(_oldValue);
	
	display.display();
}
