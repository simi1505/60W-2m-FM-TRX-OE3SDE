#ifndef _TEMPERATURE_CONTROL_PAGE_H_
#define _TEMPERATURE_CONTROL_PAGE_H_

#include "GlobalDefines.h"
#include "RenderTemperature.h"
#include "RenderPowerBar.h"
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

void TemperatureControlPage_Init(int16_t actual, int16_t setpoint, uint8_t powerSetpoint);
void TemperatureControlPage_UpdateActualTemperature(int16_t newValue);
void TemperatureControlPage_UpdateSetpointTemperature(int16_t newValue);
void TemperatureControlPage_UpdatePowerSetpoint(uint8_t newValue);

#endif // _TEMPERATURE_CONTROL_PAGE_H_
