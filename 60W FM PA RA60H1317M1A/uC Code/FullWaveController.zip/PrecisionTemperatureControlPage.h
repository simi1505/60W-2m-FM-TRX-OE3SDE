#ifndef _PRECISION_TEMPERATURE_CONTROL_PAGE_H_
#define _PRECISION_TEMPERATURE_CONTROL_PAGE_H_

#include "GlobalDefines.h"
#include "RenderTemperature.h"
#include "RenderPowerBar.h"
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;

void PrecisionTemperatureControlPage_Init(int16_t actual, int16_t setpoint, uint8_t powerSetpoint);
void PrecisionTemperatureControlPage_UpdateActualTemperature(int16_t newIntegerValue, uint8_t newTenthValue);
void PrecisionTemperatureControlPage_UpdateSetpointTemperature(int16_t newValue);
void PrecisionTemperatureControlPage_UpdatePowerSetpoint(uint8_t newValue);

#endif // _PRECISION_TEMPERATURE_CONTROL_PAGE_H_
