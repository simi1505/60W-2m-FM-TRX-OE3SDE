#include "TemperatureControlPage.h"

static const uint8_t _bargraphWidth = 120;	// Bargraph value total width

static int16_t _setpointValue = 0;
static int16_t _actualValue = 0;
static uint8_t _powerSetpointValue = 0;


void TemperatureControlPage_DrawBargraph(uint8_t newValue)
{
	static uint8_t oldTargetValue = 0;
	
	// Bargraph filling is 1px smaller than border - clear old value, then draw new value
	if (oldTargetValue > newValue)
	{
		display.fillRoundRect(1, 1, oldTargetValue, 8, 2, BLACK);
	}
	display.fillRoundRect(1, 1, newValue, 8, 2, WHITE);
	
	oldTargetValue = newValue;
}

void TemperatureControlPage_DrawSetpointTemperature()
{
	// Clear old text
	display.fillRect(30, 10, DISPLAY_WIDTH - 36, DISPLAY_HEIGHT - 10, BLACK);
	
	RenderTemperature(105, DISPLAY_HEIGHT - 1, _setpointValue, 0, NO_DECIMAL, LARGE_UNIT);
}

void TemperatureControlPage_UpdateTemperatureTarget()
{
	// Actual temperature is converted to temperature target
	int16_t absoluteError = (int16_t)(_setpointValue - _actualValue);
	uint8_t target = _bargraphWidth;
	
	if (_actualValue == TEMPERATURE_ERROR || _actualValue < 0 || _setpointValue <= 0)
	{
		TemperatureControlPage_DrawBargraph(0);
		return;
	}
	
	if (absoluteError >= 0)
	{
		// No overshoot
		target = (uint8_t)(_bargraphWidth - _bargraphWidth * (uint16_t)absoluteError / (uint16_t)_setpointValue);
	}
	
	TemperatureControlPage_DrawBargraph(target);
	
	if (absoluteError < 0)
	{
		// Overshoot triangle
		display.drawFastVLine(116, 2, 6, BLACK);
		display.drawFastVLine(117, 3, 4, BLACK);
		display.drawFastVLine(118, 4, 2, BLACK);		
	}
}

void TemperatureControlPage_UpdateSetpointTemperature(int16_t newValue)
{
	// Nothing changed - nothing to draw
	if (newValue > MAX_TEMPERATURE_SETPOINT || newValue < MIN_TEMPERATURE_SETPOINT || newValue == _setpointValue)
	{
		return;
	}
	_setpointValue = newValue;
	
	TemperatureControlPage_DrawSetpointTemperature();
	TemperatureControlPage_UpdateTemperatureTarget();
	
	display.display();
}

void TemperatureControlPage_UpdateActualTemperature(int16_t newValue)
{
	// Nothing changed - nothing to draw
	if (newValue == _actualValue)
	{
		return;
	}
	_actualValue = newValue;
	
	TemperatureControlPage_UpdateTemperatureTarget();
	
	display.display();
}

void TemperatureControlPage_UpdatePowerSetpoint(uint8_t newValue)
{
	// Nothing changed - nothing to draw
	if (newValue == _powerSetpointValue)
	{
		return;
	}
	_powerSetpointValue = newValue;
	
	RenderPowerBar(_powerSetpointValue);
	display.display();
}

void TemperatureControlPage_Init(int16_t actual, int16_t setpoint, uint8_t powerSetpoint)
{	
	_actualValue = actual;
	_setpointValue = setpoint;
	_powerSetpointValue = powerSetpoint;
	
	display.clearDisplay();
	
	// Draw border        x, y, w,                  h,  r, color
	display.drawRoundRect(0, 0, _bargraphWidth + 2, 10, 3, WHITE);
	
	// Draw up/down arrows ("setpoint")
	//                   x0, y0, x1, y1, x2, y2, color
	display.fillTriangle(13, 21, 17, 17, 21, 21, WHITE);
	display.fillTriangle(13, 25, 17, 29, 21, 25, WHITE);
	
	TemperatureControlPage_UpdateTemperatureTarget();
	TemperatureControlPage_DrawSetpointTemperature();
	RenderPowerBar(_powerSetpointValue);
	
	display.display();
}
