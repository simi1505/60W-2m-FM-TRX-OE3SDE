#ifndef _TRIGGERFAILURE_PAGE_H_
#define _TRIGGERFAILURE_PAGE_H_

#include "GlobalDefines.h"
#include "ReducedFreeSans.h"

extern Adafruit_SSD1306 display;

void TriggerfailurePage_Init(void);

#endif // _TRIGGERFAILURE_PAGE_H_
