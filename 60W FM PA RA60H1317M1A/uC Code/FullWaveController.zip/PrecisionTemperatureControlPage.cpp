#include "PrecisionTemperatureControlPage.h"

static const uint8_t _headerOffsetY = 0;	// Y offset of the header texts
static const uint8_t _valueHeight = 20;		// Height of value row

static int16_t _setpointValue = 0;
static int16_t _actualIntegerValue = 0;
static int16_t _actualTenthValue = 0;
static uint8_t _powerSetpointValue = 0;


void PrecisionTemperatureControlPage_DrawSetpointTemperature()
{
	// Clear old text (right half of the display)
	display.fillRect(DISPLAY_WIDTH / 2, DISPLAY_HEIGHT - _valueHeight, DISPLAY_WIDTH / 2 - 2, _valueHeight, BLACK);
	
	RenderTemperature(DISPLAY_WIDTH, DISPLAY_HEIGHT - 1, _setpointValue, 0, NO_DECIMAL, SMALL_UNIT);
	display.display();		
}

void PrecisionTemperatureControlPage_DrawActualTemperature()
{
	// Clear old text (left half of the display)
	display.fillRect(0, DISPLAY_HEIGHT - _valueHeight, DISPLAY_WIDTH / 2, _valueHeight, BLACK);
	
	RenderTemperature(DISPLAY_WIDTH / 2 - 1, DISPLAY_HEIGHT - 1, _actualIntegerValue, _actualTenthValue, SHOW_DECIMAL, SMALL_UNIT);
	display.display();	
}

void PrecisionTemperatureControlPage_UpdateSetpointTemperature(int16_t newValue)
{
	// Nothing changed - nothing to draw
	if (newValue > MAX_TEMPERATURE_SETPOINT || newValue < MIN_TEMPERATURE_SETPOINT || newValue == _setpointValue)
	{
		return;
	}
	_setpointValue = newValue;
	
	PrecisionTemperatureControlPage_DrawSetpointTemperature();
}

void PrecisionTemperatureControlPage_UpdateActualTemperature(int16_t newIntegerValue, uint8_t newTenthValue)
{
	// Nothing changed - nothing to draw
	if (newIntegerValue == _actualIntegerValue && newTenthValue == _actualTenthValue)
	{
		return;
	}
	_actualIntegerValue = newIntegerValue;
	_actualTenthValue = newTenthValue;
	
	PrecisionTemperatureControlPage_DrawActualTemperature();
}

void PrecisionTemperatureControlPage_UpdatePowerSetpoint(uint8_t newValue)
{
	// Nothing changed - nothing to draw
	if (newValue == _powerSetpointValue)
	{
		return;
	}
	_powerSetpointValue = newValue;
	
	RenderPowerBar(_powerSetpointValue);
	display.display();
}

void PrecisionTemperatureControlPage_Init(int16_t actual, int16_t setpoint, uint8_t powerSetpoint)
{	
	display.clearDisplay();
	
	display.setFont();
	
	// Draw "Ist" header
	display.setCursor(10, _headerOffsetY);
	display.print("Ist:");
	
	// Draw "Soll" header
	display.setCursor(DISPLAY_WIDTH / 2 + 20, _headerOffsetY);
	display.print("Soll:");
	
	display.setFont(&ReducedFreeSans);
	
	_actualIntegerValue = actual;
	_actualTenthValue = 0;
	PrecisionTemperatureControlPage_DrawActualTemperature();
	
	_setpointValue = setpoint;
	PrecisionTemperatureControlPage_DrawSetpointTemperature();
	
	_powerSetpointValue = powerSetpoint;
	RenderPowerBar(_powerSetpointValue);
	
	display.display();
}

