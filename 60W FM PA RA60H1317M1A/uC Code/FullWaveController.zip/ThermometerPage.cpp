#include "ThermometerPage.h"

static const uint8_t _headerOffsetX = 22;	// (DisplayWidth - TextWidth) / 2 = (128 - 84) / 2
static const uint8_t _textPositionX = 95;	// X position of numeric value
static const uint8_t _textPositionY = 31;	// Y position of numeric value
static const uint8_t _maxTextHeight = 18;	// Largest height of font used (determined empirically)


static int16_t _oldIntegerValue = 0;
static uint8_t _oldTenthValue = 0;
static uint8_t _oldPowerSetpoint = 0;


void ThermometerPage_DrawTemperature(int16_t integerValue, uint8_t tenthValue)
{
	// Clear old text
	display.fillRect(1, _textPositionY - _maxTextHeight + 1, 125, _maxTextHeight, BLACK);
	
	RenderTemperature(_textPositionX, _textPositionY, integerValue, tenthValue, SHOW_DECIMAL, LARGE_UNIT);
	display.display();
}

void ThermometerPage_UpdateTemperature(int16_t newIntegerValue, uint8_t newTenthValue)
{	
	// Nothing changed - nothing to draw
	if (newIntegerValue == _oldIntegerValue && newTenthValue == _oldTenthValue)
	{
		return;
	}
	
	ThermometerPage_DrawTemperature(newIntegerValue, newTenthValue);
	
	_oldIntegerValue = newIntegerValue;
	_oldTenthValue = newTenthValue;
}

void ThermometerPage_UpdatePowerSetpoint(uint8_t newValue)
{
	// Nothing changed - nothing to draw
	if (newValue == _oldPowerSetpoint)
	{
		return;
	}
	_oldPowerSetpoint = newValue;
	
	RenderPowerBar(_oldPowerSetpoint);
	display.display();
}

void ThermometerPage_Init(int16_t integerValue, int16_t tenthValue, uint8_t powerSetpoint)
{
	_oldIntegerValue = integerValue;
	_oldTenthValue = tenthValue;
	_oldPowerSetpoint = powerSetpoint;
	
	display.clearDisplay();
	
	// Use default small font for header text
	display.setFont();
	display.setCursor(_headerOffsetX, 0);
	display.print("Ist-Temperatur");
	
	RenderPowerBar(_oldPowerSetpoint);
	ThermometerPage_DrawTemperature(_oldIntegerValue, _oldTenthValue);
}
